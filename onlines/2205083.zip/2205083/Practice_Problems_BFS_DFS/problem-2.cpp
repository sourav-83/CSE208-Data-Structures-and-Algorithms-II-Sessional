/**
 * Jan25 CSE208
 * Practice Session on BFS/DFS
 *
 *
 * Complete the following code by implementing the functions. Please be mindful of the corner cases.
 * Run the provided input file.
 * Be ready to explain the generated output to the evaluator.
 *
 *
 * The usage of any online tool and/or any GenAI is absolutely forbidden in this course
 * unless otherwise mentioned.
 *
 *
 * You may consider the following:
 *
 * BFS(Graph, start_node):
    # Create a queue to store nodes to be explored
    # Create a set to track visited nodes

    # Start from the initial node and enqueue it

    # While the queue is not empty
        # Dequeue a node from the queue
        # Process the current node (e.g., print it or store it)
        # For each neighbor of the current node
            # If the neighbor has not been visited
                # Mark the neighbor as visited and enqueue it
 *
 *
 * DFS(Graph, current_node, visited):
    # Mark the current node as visited
    # Process the current node (e.g., print it or store it)

    # For each neighbor of the current node
        # If the neighbor has not been visited
            # Recursively call DFS on the neighbor
            DFS(Graph, neighbor, visited)
 *
 *
 *  **-**
*/

#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;

class Graph
{
    int V;
    vector<vector<int>> adj;
    vector<int> deleted;

public:
    Graph(int vertices)
    {
        V = vertices;
        vector<vector<int>> temp(V, vector<int>(V, 0));
        adj = temp;
        vector<int> temp2(V, 0);
        deleted = temp2;
    }

    void addEdge(int u, int v)
    {
        adj[u][v] = 1;
    }
    void removeEdge(int u, int v)
    {
        adj[u][v] = 0;
    }

    int inDegree(int u)
    {
        int degree = 0;
        for (int i = 0; i < V; i++)
        {
            if (adj[i][u])
                degree++;
        }
        return degree;
    }
    int outDegree(int u)
    {
        int degree = 0;
        for (int i = 0; i < V; i++)
        {
            if (adj[u][i])
                degree++;
        }
        return degree;
    }

    bool removeVertex(int u)
    {
        deleted[u] = 1;
        for (int i = 0; i < V; i++)
        {
            adj[i][u] = 0;
        }
    }

    void printGraph()
    {
        for (int i = 0; i < V; i++)
        {
            if (deleted[i])
                cout << "deleted vertex" << endl;
            else
            {

                for (int j = 0; j < V; j++)
                {

                    cout << adj[i][j] << " ";
                }
                cout << endl;
            }
        }
    }
    void printInNeighbors(int u)
    {

        for (int i = 0; i < V; i++)
        {
            if (adj[i][u])
                cout << i << " ";
        }
    }
    void printOutNeighbors(int u)
    {

        for (int i = 0; i < V; i++)
        {
            if (adj[u][i])
                cout << i << " ";
        }
    }
    bool isEdge(int a, int b)
    {
        return adj[a][b] == 1;
    }
};
int check = 0;
void dfs(Graph g, vector<int>&visited, int vertices,int start)
{
    
        
    
        
        
        for (int i = 0; i < vertices; i++)
        {
            if (g.isEdge(start, i))
            {
                if (visited[i] == 1)
                {
                   check = 1; 
                }

                if (visited[i] == 0)
                {    
                    visited[i] = 1;
                    dfs(g,visited,vertices,i);
                    
                }
            }
        }
        visited[start] = 2;
    

}
int main()
{
    int vertices, edges;
    cin >> vertices >> edges;
    Graph g(vertices);
    for (int i = 0; i < edges; i++)
    {
        int a, b;
        cin >> a >> b;
        g.addEdge(a, b);
    }
    vector<int> visited(vertices, 0);
    visited[0] = 1;
    dfs(g,visited,vertices,0);
    if (check==1)
    {
        cout << "No" << endl;
        return 0;
    }
    else {
        cout << "Yes" << endl;
    }
    
    
    return 0;
}